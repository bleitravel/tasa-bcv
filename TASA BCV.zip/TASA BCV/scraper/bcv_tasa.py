#!/usr/bin/env python3
"""Obtiene la tasa oficial USD/EUR publicada por el BCV y la guarda en data/tasa.json."""

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

import requests
import urllib3
from bs4 import BeautifulSoup

BCV_URL = "https://www.bcv.org.ve/"
OUTPUT_PATH = Path(__file__).resolve().parent.parent / "data" / "tasa.json"
HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
    )
}
MAX_REINTENTOS = 3
TIMEOUT = 15

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("bcv_tasa")


def obtener_html() -> str:
    """Descarga el HTML de la home del BCV, con reintentos y fallback si falla la verificacion SSL."""
    ultimo_error = None
    for intento in range(1, MAX_REINTENTOS + 1):
        try:
            try:
                resp = requests.get(BCV_URL, headers=HEADERS, timeout=TIMEOUT, verify=True)
            except requests.exceptions.SSLError:
                # El certificado del BCV suele fallar la validacion; es un problema conocido del portal.
                logger.warning("Fallo la verificacion SSL del BCV, reintentando sin verify (intento %s)", intento)
                urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
                resp = requests.get(BCV_URL, headers=HEADERS, timeout=TIMEOUT, verify=False)
            resp.raise_for_status()
            return resp.text
        except requests.exceptions.RequestException as exc:
            ultimo_error = exc
            logger.warning("Intento %s/%s fallido: %s", intento, MAX_REINTENTOS, exc)
    raise RuntimeError(f"No se pudo obtener el HTML del BCV tras {MAX_REINTENTOS} intentos") from ultimo_error


def limpiar_monto(texto: str) -> float:
    """'766,86030000' -> 766.8603 ; '1.234,56' -> 1234.56"""
    limpio = texto.strip().replace(".", "").replace(",", ".")
    return float(limpio)


def extraer_tasas(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")

    def valor_de(div_id: str) -> float:
        contenedor = soup.find("div", id=div_id)
        if contenedor is None:
            raise ValueError(f"No se encontro el contenedor #{div_id} en el HTML del BCV")
        strong = contenedor.find("strong", class_="strong-tb")
        if strong is None:
            raise ValueError(f"No se encontro el valor dentro de #{div_id}")
        return limpiar_monto(strong.get_text())

    usd = valor_de("dolar")
    eur = valor_de("euro")

    fecha_span = soup.find("span", class_="date-display-single")
    if fecha_span and fecha_span.get("content"):
        fecha = fecha_span["content"][:10]  # YYYY-MM-DD
    else:
        fecha = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    return {"tasa": usd, "usd": usd, "eur": eur, "fecha": fecha}


def guardar(datos: dict) -> None:
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(json.dumps(datos, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    logger.info("Guardado en %s: %s", OUTPUT_PATH, datos)


def main() -> int:
    try:
        html = obtener_html()
        datos = extraer_tasas(html)
        guardar(datos)
    except Exception as exc:
        logger.error("Fallo la actualizacion de la tasa BCV: %s", exc)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
