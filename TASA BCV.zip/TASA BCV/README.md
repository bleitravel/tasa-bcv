# Cloud

Tasa oficial USD/EUR del BCV, obtenida diariamente y publicada en [`data/tasa.json`](data/tasa.json), para usarla como fuente de conversión en una página web con precios en dólares.

## Cómo funciona

- [`scraper/bcv_tasa.py`](scraper/bcv_tasa.py) descarga `bcv.org.ve`, extrae la tasa USD y EUR publicada y las guarda en `data/tasa.json`.
- El workflow [`actualizar-tasa-bcv.yml`](.github/workflows/actualizar-tasa-bcv.yml) corre el script todos los días a las 6:00 PM hora Venezuela (GitHub Actions) y hace commit del resultado automáticamente.

## Uso manual

```bash
pip install -r requirements.txt
python scraper/bcv_tasa.py
```

## Formato de `data/tasa.json`

```json
{
  "tasa": 766.8603,
  "usd": 766.8603,
  "eur": 885.07948384,
  "fecha": "2026-08-13"
}
```
